const Manager = require('../models/managerSchema');
const {User, Cart} = require('../models/userSchema');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

const jwtauth = async (req, res, next)=>{
	req.creds = {};
	console.log(req.body);
	if(!req.body.token){
		req.creds.token = await jwt.sign({'type':'guest', 'id': Math.random()}, process.env.JWT_KEY);
		req.isLoggedIn = false;
		const cart = new Cart({token: req.creds.token, cart:[]});
		const a = await cart.save();
		console.log(a);
		return next();
	}
	try{
		const verify = await jwt.verify(req.body.token, process.env.JWT_KEY);
		if(verify.type == 'user'){
			const userInfo = await User.findOne({email: verify.email});
			if(userInfo){
				req.creds.email = verify.email;
				req.isLoggedIn = true;
				return next();
			}
			else{
				console.log('SECRET LEAKED!!!');
				req.creds.token = await jwt.sign({'type':'guest', 'id': Math.random()}, process.env.JWT_KEY);
				req.isLoggedIn = false;
				const cart = new Cart({token: req.creds.token, cart:[]});
				await cart.save();
				return res.json({'status':'success','token':req.creds.token});
			}
		}
		else if(verify.type == 'guest'){
			const a = await Cart.findOne({token: req.body.token});
			if(!a){
			    const cart = new Cart({token: req.body.token, cart:[]});
                	    await cart.save();
			}
			req.isLoggedIn = false;
			req.creds.token = req.body.token;
			return next();
		}
		else if(verify.type == 'manager'){
                        const a = await Manager.findOne({email: verify.email});
                        if(!a){
                            return res.json({'status':'failed', 'error':'invalid token'});
                        }
                        req.managerPriv = true;
                        req.creds.email = req.body.email;
                        return next();
                }
		else{
			console.log(req.body);
			return res.json({'status':'failed', 'error':'invalid json'});
		}
	} catch(error){
		console.log(error);
		return res.json({'status':'failed', 'error':'token expired'});
	}
}

module.exports = jwtauth;
