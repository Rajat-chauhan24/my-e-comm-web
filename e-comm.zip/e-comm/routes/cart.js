const {User, Cart} = require('../models/userSchema');
const {Product} = require('../models/productSchema');
const express = require('express');
const router = express.Router();
const jwtauth = require('../middleware/jwt-auth');

router.post('/', jwtauth, async (req, res)=>{
    try{
	console.log(req.creds);
        if(req.isLoggedIn){
            const email = req.creds.email;
            const wishlist = req.body.wishlist;
            const userLogin = await User.findOne({email: email});
            res.json({'status':'success', 'result':userLogin[wishlist?'wishlist':'cart']});
        }
        else{
            const token = req.creds.token;
            const tempCart = await Cart.findOne({token: token});
            res.json({'status':'success', 'result':tempCart['cart']});
        }
    } catch(error){
        console.log(error);
        res.status(500).json({'status':'failed', 'error':'internal error'});
    }
});

router.post('/add', jwtauth, async (req, res)=>{
    try{
	const item = req.body.item;
	const product = await Product.findOne({product_id: item.product_id});
	if(item.shade){
		console.log();
		const i = await {...product}._doc.color.shades.find(y=> {return y.name == item.shade});
		console.log(i.image, 'i');
		item.image = i.image[0];
		item.price = i.price;
	}
	else{
		item.image = product.images[0];
		item.price = product.price;
	}
	console.log(item);
        if(req.isLoggedIn){
            const email = req.creds.email;
            const wishlist = req.body.wishlist;
            if(wishlist){
                await User.findOneAndUpdate({email: email}, {$push: {wishlist: item}});
            }
            else{
                await User.findOneAndUpdate({email: email}, {$push: {cart: item}});
            }
            res.json({'status':'success'});
        }
        else{
            var obj = {'status':'success'};
            const token = req.creds.token;
            await Cart.findOneAndUpdate({token: token}, {$push: {cart: item}});
            res.json(obj);
        }
    } catch(error){
        console.log(error);
        res.status(500).json({'status':'failed', 'error':'internal error'});
    }
});

router.post('/remove', jwtauth, async (req, res)=>{
    try{
        if(req.isLoggedIn){
            const item = req.body.item;
            const email = req.creds.email;
            const wishlist = req.body.wishlist;
            const userInfo = await User.findOne({email: email});
            if(wishlist && userInfo['wishlist'].length){
                await User.findOneAndUpdate({email: email}, {$pull: {wishlist:{product_id: item.product_id, shade: item.shade}}});
            }
            else{
                if(userInfo['cart'].length){
                    await User.findOneAndUpdate({email: email}, {$pull: {cart:{product_id: item.product_id, shade: item.shade}}});   
            	}
            }
            res.json({'status':'success'});
        }
        else{
            const item = req.body.item;
            const token = req.creds.token;
            const tempCart = await Cart.findOne({token: token});
            if(tempCart['cart'].length){
                await Cart.findOneAndUpdate({token: token}, {$pull: {cart:{product_id: item.product_id, shade: item.shade}}});
            }
            res.json({'status':'success'});
        }
    } catch(error){
        console.log(error);
        res.status(500).json({'staus':'failed', 'error':'internal error'});
    }
});

router.post('/change/quantity', jwtauth, async (req, res)=>{
    try{
        const {id, shade, quantity} = req.body.item;
        const obj = {product_id: id};
	shade?obj['shade'] = shade:null;
	if(req.isLoggedIn){
            const email = req.creds.email;
            await User.findOneAndUpdate({email: email, cart:{$elemMatch:obj}}, {$set:{'cart.$.quantity': quantity}});
        }
        else{
            const token = req.creds.token;
            await Cart.findOneAndUpdate({token: token, cart:{$elemMatch:obj}}, {$set:{'cart.$.quantity': quantity}});
        }
        res.json({'status':'success'});
    } catch(error){
        console.log(error);
        res.status(500).json({'status':'failed', 'error':'internal error'});
    }
});

module.exports = router;
