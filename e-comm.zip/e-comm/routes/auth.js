const {User, Cart} = require('../models/userSchema');
const express =  require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const jwtauth = require('../middleware/jwt-auth');

router.post('/register', jwtauth, async (req, res)=>{
    try{
        const {firstname, lastname, email, password, saveCart} = req.body.signup;
        console.log(req.body);
        if(!firstname || !lastname || !email || !password){
            return res.status(422).json({'status':'failed', 'error':'missing parameters'});
        }
        const token = req.creds.token;
        const emailExist = await User.findOne({email: email});
        if(emailExist){
            return res.status(422).json({'status':'failed', 'error':'email already registered'});
        }
        const newToken = jwt.sign({'email': email, 'type':'user'}, process.env.JWT_KEY);
	const tempCart = await Cart.findOne({token: token});
       	const user = new User({firstname, lastname, email, password, cart: tempCart['cart'], tokens:[{token: newToken}]});
        const userLogin = await user.save();
        res.status(201).json({'status':'success', 'token':newToken, 'firstname':userLogin['firstname'], 'lastname':userLogin['lastname'], 'email':userLogin['email'], 'cart':userLogin['cart']});
        await Cart.findOneAndDelete({token: token});
    } catch(error){
        console.log(error);
        res.status(500).json({'status':'failed', 'error':'something went wrong'});
    }
});

router.post('/signin', jwtauth, async (req, res)=>{
    try{console.log(req);
        const {email, password, saveCart, expires} = req.body.login;
        const token = req.creds.token;
       if(!email || !password){
            console.log(req.body);
            return res.status(422).json({'status':'failed', 'error':'missing parameters'});
        }
        const userLogin = await User.findOne({email: email});
        if(userLogin){
            console.log("password: ",userLogin['password']);
            const isMatch = await bcrypt.compare(password, userLogin.password);
            if(!isMatch){
                return res.status(400).json({'status':'failed', 'error':'invalid credentials'});
            }
            const newToken = await jwt.sign({'email':email, 'type':'user'}, process.env.JWT_KEY);
            const tempCart = await Cart.findOne({token: token});
            console.log(newToken);
	    if(saveCart){
                if(tempCart.cart.length){
                    await User.findOneAndUpdate({email: email}, {cart: tempCart.cart, tokens:{$push: {token: newToken}}});
                }
            }
            else{
                await User.findOneAndUpdate({email: email}, {tokens:{$push: {token: newToken}}});
            }               
	    console.log(newToken);
            res.json({'status':'success', 'token':newToken ,'firstname':userLogin['firstname'], 'lastname':userLogin['lastname'], 'email':userLogin['email'], 'cart':userLogin['cart']});
            await Cart.findOneAndDelete({token: token});
        }
        else{
            res.status(400).json({'status':'failed', 'error':'invalid credentials'});
        }
        console.log(req);
    } catch(error){
        console.log(error);
        res.status(500).json({'status':'failed', 'error':'something went wrong'});
    }
});

module.exports = router;
