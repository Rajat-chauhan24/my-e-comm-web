const express = require('express');
const { v4: uuidv4} = require("uuid");
const {User} = require('../models/userSchema');
const Payment = require('../models/paymentSchema');
const {Product} = require('../models/productSchema');
const router = express.Router();
const jwtauth = require('../middleware/jwt-auth');
const razorpay = require('razorpay');
const crypto = require('crypto');
const transporter = require('../services/email');

const razorpayInstance = new razorpay({
	key_id: process.env.RAZORPAY_KEY_ID,
	key_secret: process.env.RAZORPAY_KEY_SECRET
});


router.post('/payment/online/order', jwtauth, async (req, res)=>{
	if(req.isLoggedIn){
		console.log(req.body);
		const {title, receipt, notes} = req.body.payment;
		const email = req.creds.email;
		const userInfo = await User.findOne({email: email});
		if(userInfo){
			console.log(userInfo['cart']);
			console.log("Working");
			console.log(userInfo);
			const i = userInfo['address'].findIndex(item => item.title == title);
			const address = userInfo['address'][i];
			console.log(address);
			let amount = 0;
			console.log(amount);
			await userInfo['cart'].forEach((item, index)=>{
				amount += (item.price*item.quantity)*100;
				console.log(amount);
			});
			const currency = 'INR';
			razorpayInstance.orders.create({amount, currency, receipt, notes}, (err, order)=>{
				if(err){ 
					console.log(err);
					res.json({"status":false});
				}
				else{
					const payInfo = new Payment({email: email, order_id: order['id'], cart: userInfo['cart'], address: address, amount: amount, online:{option: true}, verified: false});
					payInfo.save();
					res.json({"status": true, "order":order});
				}
			});
		}
		else{
			console.log("User doesn't exist");
			res.json({"status":false});
		}
	}
	else{
		res.json({'status':'failed'});
		console.log("Error");
	}
});

router.post('/payment/online/verify', jwtauth, async (req, res)=>{
	if(req.isLoggedIn){
		const email = req.creds.email;
		const response = req.body.response;
		if(response['razorpay_signature']){
			const userInfo = await Payment.findOne({email: email, order_id: response.razorpay_order_id});
			await Payment.findOneAndUpdate({email: email, order_id: response.razorpay_order_id}, {online:{payment_info:{razorpay_order_id: response.razorpay_order_id, razorpay_signature: response.razorpay_signature, razorpay_payment_id: response.razorpay_payment_id}, option: true}});
			
            let body = userInfo['order_id'] + '|' + response.razorpay_payment_id;
			var signature = await crypto.createHmac('sha256', process.env.RAZORPAY_KEY_SECRET).update(body.toString()).digest('hex');
			
            if(response.razorpay_signature != signature) {
				res.json({"status":"Error"});
				console.log("Error");
				await Payment.findOneAndDelete({order_id: response.razorpay_order_id});
			}   
			else{
				await Payment.findOneAndUpdate({email: email, order_id: response.razorpay_order_id, online:{option: true, payment_info: response}}, {verified: true});
				
                let t = '<div style="width: 30%; height: 20px; color: black; background: lavender">TITLE</div><div style="width: 30%; height: 20px">SHADE</div><div style="width: 20%; height: 20px">PRICE</div><div style="width: 20%; height: 20px">QUANTITY</div>\n';
                await userInfo['cart'].forEach((item, index)=>{
					t += (item.title+'\t'+(item.shade?item.shade:'  -  ')+'\t'+item.price+'\tx'+item.quantity+'\n').toString();
				});	
                var mailOptions = {
					from: process.env.MAIL_ID,
					to: email,
					subject: 'Order placed',
					html: 'Your order has been placed.\n' + t + 'Amount paid: ' + userInfo['amount']
				};

				transporter.sendMail(mailOptions, function(error, info){
	  				if (error) {
						console.log(error);
	  				}
					else{
						console.log('Email sent: ' + info.response);
					}
				});
				
                mailOptions['to'] = process.env.ADMIN_MAIL_ID;
				mailOptions['html'] = `Order placed by ${email}.\n` + t + `Mode: UPI\nAmount: ${userInfo['amount']}`;
				
                transporter.sendMail(mailOptions, function(error, info){
					if (error) {
						console.log(error);
					}
					else{
						console.log('Email sent: ' + info.response);
					}
				});
				await User.findOneAndUpdate({email: email}, {cart:[]});
				res.json({'status': 'success'});
				console.log("Success");
			}
		}
		else{
			res.json({'status':'failed'});
		}
	}
	else{
		res.json({"status":"Error"});
		console.log("Error");
		await Payment.findOneAndDelete({order_id: response.razorpay_order_id});
	}
});


router.post('/payment/offline', jwtauth, async (req, res)=>{
	try{
		if(req.isLoggedIn){
			const email = req.creds.email;
			const title = req.body.title;
			const userInfo = await User.findOne({email: email});
			var amount = 0;
			var t = '<div style="width: 30%; height: 20px; color: black; background: lavender">TITLE</div><div style="width: 30%; height: 20px">SHADE</div><div style="width: 20%; height: 20px">PRICE</div><div style="width: 20%; height: 20px">QUANTITY</div>\n';
			
            await userInfo['cart'].forEach((item, index)=>{
				t += (item.title+'\t'+(item.shade?item.shade:'  -  ')+'\t'+item.price+'\tx'+item.quantity+'\n').toString();
			});

            const i = userInfo['address'].indexOf(item => item.title == title);
            const address = userInfo['address'][i];
			const payInfo = new Payment({email: email, number: userInfo['number'], online:{option: false}, offline: true, cart: userInfo['cart'], address: address, amount: amount, order_id: uuidv4()});
			console.log(await payInfo.save(), 'DONE');
			
            var mailOptions = {
				from: process.env.MAIL_ID,
				to: email,
				subject: 'Order placed',
				html: 'Your order has been placed.\n' + t + `Amount to be paid: ${amount}`
			};
			
            transporter.sendMail(mailOptions, function(error, info){
				if (error) {
					console.log(error);
				} else {
					console.log('Email sent: ' + info.response);
				}
			});
			
            mailOptions['to'] = process.env.ADMIN_MAIL_ID;
			mailOptions['html'] = `Order placed by ${email}.\n` + t + `Mode: Cash on delivery\nAmount: ${amount}`;
			
            transporter.sendMail(mailOptions, function(error, info){
				if (error) {
					console.log(error);
				} else {
					console.log('Email sent: ' + info.response);
				}
			});
            await User.findOneAndUpdate({email: email}, {cart:[]});
			res.json({'status':'success'});
		}
		else{
			res.json({'status':'failed', 'error':'user isn\'t logged in'});
		}
	} catch(error){
		console.log(error);
		res.json({'status':'failed', 'error':'internal error'});
	}
});

module.exports = router;
