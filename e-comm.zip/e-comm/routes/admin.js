const Manager = require('../models/managerSchema');
const Admin = require('../models/adminSchema');
const express = require('express');
const router = express.Router();
const jwtauth = require('../middleware/jwt-auth');
const bcrypt = require('bcrypt');

router.post('/add/managers', /*jwtauth,*/ async (req, res)=>{
    try{
        const {email, mobile_no, password, name} = req.body;
        if(!email || !mobile_no || !password || !name){
            console.log('Missing parameters: ', email, password, mobile_no);
            return res.status(401).json({'status':'failed', 'error':'missing parameters'});
        }
        const credEmail = await Manager.findOne({email: email});
        const credMobile = await Manager.findOne({mobile_no: mobile_no});
        if(credEmail){
            console.log('Email already registered: ', email);
            return res.status(401).json({'status':'failed', 'error':'email already registered'});
        }
        else if(credMobile){
            console.log('Mobile no. already registered: ', mobile_no);
            return res.status(401).json({'status':'failed', 'error':'mobile no. already registered'});
        }
        const manager = new Manager({name: name, email: email, mobile_no: mobile_no, password: password});         
        await manager.save();
        console.log('Manager registered.');
        return res.status(301).json({'status':'success'});
    } catch(error){
        console.log(error);
        return res.status(500).json({'status':'failed', 'error':'internal error'});
    }
});

router.post('/login', async (req, res)=>{
    try{
        const {email, password} = req.body;
        if(!email || !password){
            console.log('missing parameters: ', email, password);
            return res.status(400).json({'status':'failed', 'error':'missing parameters'});
        }
        const adminLogin = await Admin.findOne({email: email, password: password});
        if(!adminLogin){
            console.log('Invalid credentials: ', email, password);
            return res.status(400).json({'status':'failed', 'error':'invalid credentials'});
        }
        const isMatch = bcrypt.compare(password, adminLogin.password);
        if(!isMatch){
            console.log('Wrong password: ', password);
            return res.status(400).json({'status':'failed', 'error':'invalid credentials'});
        }
        return res.status(301).json({'status':'success', 'email': adminLogin['email']});
    } catch(error){
        console.log(error);
        res.status(500).json({'status':'failed', 'error':'internal error'});
    }
});

module.exports = router;
