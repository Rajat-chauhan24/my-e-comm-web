const {Product, Combo, BuyGet, Menu} = require('../models/productSchema');
const express = require('express');
const router = express.Router();

router.post('/menu', async (req, res)=>{
    try{
        const menu = await Menu.find({});
        res.send(menu);
    } catch(error){
        console.log(error);
        res.status(500).json({'status':'failed', 'error':'internal error'});
    }
});

router.get('/', async (req, res)=>{
	const a = await Product.find();
	res.json(a);
});

router.get('/new', async (req, res)=>{
    try{ 
    	const products = await Product.find().sort({$natural:-1}).limit(20);
    	const p = [];
        products.forEach((item, index)=>{
    	    const doc = {...item};
            const a = {title: item.title, product_id: item.product_id, category: item.category, name: item.name, brand: item.brand, images: item.images};
    	    
            if(doc._doc.color.availability){
                a.shades = doc._doc.color.shades;
    	    }
    	    else{
    	    	a.price = item.price;
    	    	a.stock = item.stock;
    	    }
    	    p.push(a);
        });
        res.json(p);
    } catch(error){
        console.log(error);
        res.status(500).json({'status':'failed', 'error':'internal error'});
    }
});

router.get('/offers', async (req, res)=>{
    try{
        var obj = {};
        const discountList = await Product.find({offers:{discount:{availability: true}}});
        const comboList = await Combo.find({});
        const buyGetList = await BuyGet.find({});
        if(discountList.length){
           obj['discounts'] = productList; 
        }
        if(comboList.length){
            obj['combos'] = comboList;
        }
        if(buyGetList.length){
            obj['buyGets'] = buyGetList;
        }
        return res.json({'status':'success', 'result': obj});
    } catch(error){
        console.log(error);
        return res.status(500).json({'status':'failed', 'error':'internal error'});
    }
});

router.get('/productid/:product_id', async (req, res)=>{
    try{
        const {product_id} = req.params;
        if(!product_id){
            return res.json({'status':'failed', 'error':'no input'});
        }
        const product = await Product.findOne({product_id: product_id});
        if(!product){
            return res.json({'status':'failed', 'error':'invalid product id'});
        }
	const p = {...product}._doc;
        res.json({'status':'success', 'result': p});
    } catch(error){
        console.log(error);
        return res.status(500).json({'status':'failed', 'error':'internal error'});
    }
});

router.post('/search/', async (req, res)=>{
    try{
        var obj = {};
        const {search, category, name, brand} = req.body;
        if(!search && !category && !name && !brand){
            return res.json({'status':'failed', 'error':'no input'}); 
        }
        category? (obj['category'] = {$regex: ".*"+category+".*"}):null;
        name? (obj['name'] = {$regex: ".*"+name+".*"}):null;
        brand? (obj['brand'] = {$regex: ".*"+brand+".*"}):null;
        if(search){
            const words = search.split();
            obj['title'] = {$regex: ".*"+search+".*", $options : 'i'};

            if(words.length == 1){
                const productList = await Product.find(obj);
                const p = [];
                productList.forEach((item)=>{
                    const doc = {...item};
                    const a = {title: item.title, product_id: item.product_id, category: item.category, name: item.name, brand: item.brand, images: item.images};
            
                    if(doc._doc.color.availability){
                        a.shades = doc._doc.color.shades;
                    }
                    else{
                        a.price = item.price;
                        a.stock = item.stock;
                    }
                    p.push(a);
                });
                return res.json({'status':'success', 'result':p.reverse()});
            }
            else{
                const productList = await Product.find(obj);
                words.forEach(async (item, index)=>{
                    obj['title'] = {$regex: ".*"+item+".*", $options : 'i'};
                    productList.push(...(await Product.find(obj)).reverse());
                });
                const unique = [...new Set(productList)];
                
                const p = [];
                unique.forEach((item, index)=>{
                    const doc = {...item};
                    const a = {title: item.title, product_id: item.product_id, category: item.category, name: item.name, brand: item.brand, images: item.images};
                    
                    if(doc._doc.color.availability){
                        a.shades = doc._doc.color.shades;
                    }
                    else{
                        a.price = item.price;
                        a.stock = item.stock;
                    }
                    p.push(a);
                });
                return res.json({'status':'success', 'result':p});
            }
        }
        else{
            const productList = await Product.find(obj);
            const p = [];
            productList.forEach((item)=>{
                const doc = {...item};
                const a = {title: item.title, product_id: item.product_id, category: item.category, name: item.name, brand: item.brand, images: item.images};
                
                if(doc._doc.color.availability){
                    a.shades = doc._doc.color.shades;
                }
                else{
                    a.price = item.price;
                    a.stock = item.stock;
                }
                p.push(a);
            });
            return res.json({'status':'success', 'result':p.reverse()});
        }
    } catch(error){
        console.log(error);
        return res.status(500).json({'status':'failed', 'error':'internal error'});
    }
});

module.exports = router;
