const {Product} = require('../models/productSchema');
const Manager = require('../models/managerSchema');
const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const jwtauth = require('../middleware/jwt-auth');
const jwt = require('jsonwebtoken');

router.post('/add/product', jwtauth, async (req, res)=>{
    try{
	console.log(req.body);
	if(req.managerPriv){
        const {name, title, brand, category, description, shades, stock, images, price} = req.body.product;
        if(!name || !title || !brand || !category || !description || !((shades && !(price && stock && images)) || (!shades && (price && stock && images)))){
            console.log('Missing parameters');
            return res.status(401).json({'status':'failed', 'error':'missing parameters'});
        }
	const obj = {title: title, name: name, brand: brand, category: category, description: description};
	if(shades && shades.length){
	    if(!shades.price || !shades.image.length || !shades.name || !shade.code || !shade.quantity){
	        return res.json({'status':'failed', 'error':'missing parameters'});	
	    }
	    obj['color'] = {availability: true, shades: shades};
	}
	else{
	    obj['color'] = {availability: false, shades:[]};
	    obj['price'] = price;
            obj['stock'] = stock;
            obj['images'] = images;
	}
        const productExist = await Product.findOne({title: title});
        if(productExist){
            console.log('Product already exists: ', title);
            return res.status(401).json({'status':'failed', 'error':'product exists in database'});
        }
	const id = await Product.find().sort({$natural:-1}).limit(1);
	console.log(parseInt(id[0].product_id.slice(4)));
	const product_id = 'PUD' + (parseInt(id[0].product_id.slice(4))+1).toString();
        obj['product_id'] = product_id;
	console.log(obj);
	const product = new Product(obj);         
        await product.save();
        console.log('product added.');
        return res.status(301).json({'status':'success'});
	} else {
		res.json({'status':'failed','error':'user not privileged'});
	}
    } catch(error){
        console.log(error);
        return res.status(500).json({'status':'failed', 'error':'internal error'});
    }
});

router.post('/edit/product', jwtauth, async (req, res)=>{
    try{
	console.log(req.body);
        const editList = req.body.edits;
        editList.forEach(async (x,y)=>{
            await Product.findOneAndUpdate({product_id: x.product_id}, x);
        });
        return res.status(301).json({'status':'success'});
    } catch(error){
        console.log(error);
        return res.status(500).json({'status':'failed', 'error':'internal error'});
    }
});

router.post('/remove/product', jwtauth, async (req, res)=>{
    try{
        const removeList = req.body.removed;
        removeList.forEach(async (x, y)=>{
            await Product.findOneAndDelete({product_id: x.product_id});
        });
	res.json({'status':'success'});
    } catch(error){
        console.log(error);
        return res.status(500).json({'status':'failed', 'error':'internal error'});
    }
});

router.post('/add/offer', jwtauth, async (req, res)=>{
    try{
        const {type, obj} = req.body;
        if(type == 'buyget'){
           //check what info does the obj need to have for each conditions 
        }
        else if(type == 'discount'){

        }
        else if(type == 'combo'){

        }
        else{
            console.log('Type of offer: ', type);
            return res.status(401).json({'status':'failed', 'error':'invalid parameters'});
        }
    } catch(error){
        console.log(error);
        return res.status(500).json({'status':'failed', 'error':'internal error'});
    }
});

router.post('/login', jwtauth, async (req, res)=>{
    try{
       	const {email, password} = req.body;
        if(!email || !password){
            console.log(req.body);
            return res.status(422).json({'status':'failed', 'error':'missing parameters'});
        }
        const userLogin = await Manager.findOne({email: email});
        if(userLogin){
            console.log("password: ",userLogin['password']);
            const isMatch = await bcrypt.compare(password, userLogin.password);
            if(!isMatch){
                return res.status(400).json({'status':'failed', 'error':'invalid credentials'});
            }
            const newToken = await jwt.sign({'email':email, 'type':'manager'}, process.env.JWT_KEY);
            console.log(newToken);
	    console.log(newToken);
            res.json({'status':'success', 'token':newToken ,'email':userLogin['email']});
        }
        else{
            res.status(400).json({'status':'failed', 'error':'invalid credentials'});
        }
        console.log(req);

    } catch(error){
        console.log(error);
        res.status(500).json({'status':'failed', 'error':'internal error'});
    }    
});

module.exports = router;
