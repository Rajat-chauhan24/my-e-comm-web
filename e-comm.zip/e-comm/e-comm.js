const express = require('express');
const mongoose = require('mongoose');
require('dotenv').config();
const cors = require('cors');
const app = express();
const port = process.env.PORT || 8080;
const path = require('path');
const DB = process.env.DB_ADDR;
const jwtauth = require('./middleware/jwt-auth');

mongoose.connect(DB).then(()=>{
    console.log('Connection successful');
}).catch((err)=>{
    console.log(err);
    process.exit(1);
});

app.use(cors());
app.use(express.json());
app.use('/media', express.static(path.join(__dirname,"media")));
app.use('/public', express.static(path.join(__dirname,"public")));
app.use('/auth', require('./routes/auth'));
app.use('/profile', require('./routes/profile'));
app.use('/admin', require('./routes/admin'));
app.use('/manager', require('./routes/manager'));
app.use('/product', require('./routes/product'));
app.use('/cart', require('./routes/cart'));
app.use('/checkout', require('./routes/checkout'));

app.post('/', jwtauth, (req, res)=>{	
	res.json({'token': req.creds.token});
});

app.listen(port, process.env.IP, ()=>{
    console.log("Server is running at port %s", port);
});
