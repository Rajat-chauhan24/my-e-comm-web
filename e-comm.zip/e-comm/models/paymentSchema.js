const mongoose = require('mongoose');

const paymentSchema = mongoose.Schema({
    email:{
        type: String,
        required: true
    },
    amount:{
        type: Number,
        required: true
    },
    order_id:{
        type: String,
        required: true
    },
    online:{
        option:{
            type: Boolean,
            default: false
        },
        payment_info: {
            razorpay_order_id:{
                type: String,
                default: "NONE",
                required: true
            },
            razorpay_payment_id:{
                type: String,
                default: "NONE",
                required: true
            },
            razorpay_signature:{
                type: String,
                default: "NONE",
                required: true
            }

        }
    },
    verified:{
	type: Boolean,
	default: false
    },
    offline:{
        type: Boolean,
        default: false
    },
    cart:[
        {
            product_id:{
                type: String,
                required: true
            },
            title:{
                type: String,
                required: true
            },
            shade:{
                type: String
            },
            quantity:{
                type: Number,
                required: true
            },
            price:{
                type: Number,
                required: true
            }
        }
    ],
    address:{
        title:{
            type: String,
            required: true
        },
        value:{
            pin:{
                type: Number
            },
            house:{
                type: String
            },
            street:{
                type: String
            },
            city:{
                type: String
            },
            state:{
                type: String
	       }
	}
    },
    delivered:{
        type: Boolean,
        default: false
    }
});

const Payment = mongoose.model('payments', paymentSchema);
module.exports = Payment;
