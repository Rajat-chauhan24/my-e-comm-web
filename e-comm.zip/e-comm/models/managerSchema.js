const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const managerSchema = new mongoose.Schema({
    name:{
        type: String,
        required: true
    },
    email:{
        type: String,
        required: true
    },
    mobile_no:{
        type: String,
        required: true
    },
    password:{
        type: String,
        required: true
    }
});

managerSchema.pre("save", async function(next){
    if(this.isModified("password")){
        this.password = await bcrypt.hash(this.password, 16);
    }
    next();
});

const Manager = mongoose.model('managers', managerSchema);
module.exports = Manager;
