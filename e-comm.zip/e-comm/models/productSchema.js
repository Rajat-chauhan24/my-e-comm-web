const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
    product_id:{
        type: String,
        required: true
    },
    name:{
        type: String,
        required: true
    },
    title:{
        type: String,
        required: true
    },
    brand:{
        type: String,
        required: true
    },
    images:[],
    price:{
        type: Number,
        default: 0
    },
    category:{
        type: String,
        required: true
    },
    description:{
        type: String,
        required: true
    },
    color:{
        availability:{
            type: Boolean,
            required: true
        },
        quantity:{
            type: Number
        },
        shades:[
            {
                name:{
                    type: String,
                    required: true
                },
                code:{
                    type: String,
                    required: true
                },
                price:{
                    type: Number,
                    required: true
                },
                image:[],
                quantity:{
                    type: Number,
                    required: true
                }
            }
        ]
    },
    stock:{
        type: Number,
        default: 0
    },
    offers:{
        discount:{
            availability:{
                type: Boolean,
                default: false
            },
            value:{
                type: Number,
                default: 0
            }
        },
        combo:{
            availability:{
                type: Boolean,
                default: false
            },
            value:{
                type: String
            }
        },
        buyGet:{
            availability:{
                type: Boolean, 
                default: false
            },
            value:{
                type: String
            }
        }
    },
    reviews:[
        {
            rating:{
                type: Number
            },
            review:{
                type: String
            }
        }
    ]
});

const comboSchema = new mongoose.Schema({
    id:{
        type: String,
        required: true
    },
    price:{
        type: Number,
        required: true
    },
    products:[
        {
            name:{
                type: String,
                required: true
            },
            product_id:{
                type: String,
                required: true
            },
            color:{
                availablity:{
                    type: Boolean,
                    required: true
                },
                shades:[
                    {
                        name:{
                            type: String
                        },
                        code:{
                            type: String
                        }
                    }
                ]
            }
        }
    ]
});

const buyGetSchema = new mongoose.Schema({
    id:{
        type: String,
        required: true
    },
    price:{
        type: Number,
        required: true
    },
    main:{
        name:{
            type: String,
            required: true
        },
        product_id:{
            type: String,
            required: true
        },
        price:{
            type: Number, 
            requied: true
        },
        quantity:{
            type: Number, 
            required: true
        }
    },
    products:[
        {
            name:{
                type: String,
                required: true
            },
            product_id:{
                type: String,
                required: true
            },
            color:{
                availability:{
                    type: Boolean,
                    required: true
                },
                shades:[
                    {
                        name:{
                            type: String
                        },
                        code:{
                            type: String
                        }
                    }
                ]
            }
        }
    ]
}); 

const menuSchema = new mongoose.Schema({
    name:{
        type: String,
        required: true
    },
    list:[]
});

const Product = mongoose.model('products', productSchema);
const Combo = mongoose.model('combos', comboSchema);
const BuyGet = mongoose.model('buygets', buyGetSchema);
const Menu = mongoose.model('menu', menuSchema);
module.exports = {Product, Combo, BuyGet, Menu};
