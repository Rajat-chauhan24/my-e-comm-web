const mongoose = require('mongoose');

const adminSchema = new mongoose.Schema({
    name:{
        type: String,
        required: true
    },
    email:{
        type: String,
        required: true
    },
    mobile_no:{
        type: String,
    },
    password:{
        type: String,
        required: true
    }
});

adminSchema.pre("save", async function(next){
    if(this.isModified("password")){
        this.password = await bcrypt.hash(this.password, 16);
    }
    next();
});

const Admin = mongoose.model('admins', adminSchema);

module.exports = Admin;
