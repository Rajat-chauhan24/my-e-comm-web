const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
    firstname:{
        type: String,
        required: true
    },
    lastname:{
        type: String,
        required: true
    },
    contact:{
        type: String,
        default: 'NULL',
        required: true
    },
    email:{
        type: String,
        required: true
    },
    profile:{
        type: String,
        default: 'media/profile/default.jpg'
    },
    password:{
        type: String,
        required: true
    },
    cart:[
        {
            product_id:{
                type: String
            },
            title:{
                type: String
            },
            shade:{
                type: String
            },
	    image:{
		type: String
	    },
            quantity:{
                type: Number,
                default: 1
            },
            price:{
                type: Number
            }
        }
    ],
    wishlist:[
        {
            product_id:{
                type: String
            },
            title:{
                type: String
            },
            shade:{
                type: String
            },
            image:{
                type: String
            },
            price:{
                type: Number
            }
        }
    ],
    address:[
        {
            title:{
                type: String
            },
            value:{
                pin:{
                    type: Number
                },
                house:{
                    type: String
                },
                street:{
                    type: String
                },
                city:{
                    type: String
                },
                state:{
                    type: String
                }
            }
        }
    ]
});

const cartSchema = new mongoose.Schema({
    token:{
        type: String,
        required: true
    },
    cart:[
	{
            product_id:{
                type: String
            },
            title:{
                type: String
            },
            shade:{
                type: String
            },
	    image:{
		type: String
	    },
            quantity:{
                type: Number,
                default: 1
            },
            price:{
                type: Number
            }
        }
    ],
    expireAt:{
        type: Date,
        default: Date.now(),
        index: {expires: '12h'}
    }
});

userSchema.pre("save", async function(next){
    if(this.isModified("password")){
        this.password = await bcrypt.hash(this.password, 16);
    }
    next();
});

const User = mongoose.model("users", userSchema);
const Cart = mongoose.model("carts", cartSchema);

module.exports = {User, Cart};
